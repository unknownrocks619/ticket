<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrganisationStudent extends Model
{
    use HasFactory;

    // public function organisations()
    // {
    //     // return $this->belongsToMany(Organisation::class,)
    // }
}
