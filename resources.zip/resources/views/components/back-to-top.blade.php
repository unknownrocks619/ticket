<button onclick="topFunction()" id="myBtn" title="Go to top">
    <i class="fas fa-arrow-alt-circle-up" style="font-size: 30px"></i>
</button>
<script type="text/javascript">
    function topFunction() {
        window.scrollTo({
            top: 0
            , behavior: "smooth"
        });
    }
</script>