@extends("themes.frontend.master")

@section("content")

@endsection