<div class="modal fade" id="{{ $modal }}" tabindex="-1" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content" id="modal-content">
            {{ $slot }}
        </div>
    </div>
</div>