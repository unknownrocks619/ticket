@foreach ($widget->widgets as $widget)
<section class="mt-5">
    <div id="video-info" class="vert-center-container">
        <div class="d-flex justify-content-center">

        </div>
    </div>
</section>
@endforeach